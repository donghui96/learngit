#ifndef __LED_H
#define __LED_H	 
#include "sys.h"
 
#define LED2 PAout(12)	// PC13
#define LED1 PAout(11)	// PC13
#define LED PAout(10)	// PC13
void LED_Init(void);//��ʼ��	
void LED1_Init(void);//��ʼ��	

void LED2_Init(void);//��ʼ��	
#endif
